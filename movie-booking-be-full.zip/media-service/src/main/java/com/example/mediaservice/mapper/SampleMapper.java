package com.example.mediaservice.mapper;
import org.mapstruct.*;
@Mapper(componentModel="spring")
public interface SampleMapper {}