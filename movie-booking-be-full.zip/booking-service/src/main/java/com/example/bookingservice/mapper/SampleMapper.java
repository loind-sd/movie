package com.example.bookingservice.mapper;
import org.mapstruct.*;
@Mapper(componentModel="spring")
public interface SampleMapper {}