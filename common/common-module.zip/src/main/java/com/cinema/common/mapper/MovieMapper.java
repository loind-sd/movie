package com.cinema.common.mapper;

import com.cinema.common.dto.MovieDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MovieMapper {
    MovieDto toDto(com.cinema.service.domain.Movie movie);
    // Note: domain.Movie is intentionally not provided here. Each service implements its own entity and can map using this interface or local mapper.
}
