package com.example.cinemaservice.mapper;
import org.mapstruct.*;
@Mapper(componentModel="spring")
public interface SampleMapper {}