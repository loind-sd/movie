package com.example.paymentservice.mapper;
import org.mapstruct.*;
@Mapper(componentModel="spring")
public interface SampleMapper {}