package com.cinema.common.enums;

public enum MovieStatus {
    UPCOMING,
    RUNNING,
    ENDED,
    CANCELLED
}
