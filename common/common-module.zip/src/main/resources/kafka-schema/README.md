Place canonical JSON schemas for Kafka topics here.
Services can use these for validation / producing contract tests / schema registry (if using JSON Schema registry).
