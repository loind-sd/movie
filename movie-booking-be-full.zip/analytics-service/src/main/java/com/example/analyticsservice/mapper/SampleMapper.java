package com.example.analyticsservice.mapper;
import org.mapstruct.*;
@Mapper(componentModel="spring")
public interface SampleMapper {}